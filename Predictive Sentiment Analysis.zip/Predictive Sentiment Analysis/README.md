Project title - Stockport | Predictive Sentiment Analysis

Team Code-Team 22

Team Members
1.RITHVIKA N - 1NC20CD021
2.RAKSHITH D - 1OX21IS085
3.SUHAS B R  - 1OX21IS113
4.MEDHAA P B - 1RN21IS086
5.MEGHANA R  - 1SJ21EC079

Predictive sentiment analysis involves using natural language processing (NLP) and machine learning techniques to analyze text data and predict the sentiment expressed within it. Sentiment analysis can be applied to various types of text, including social media posts, news articles, customer reviews, and more. 

